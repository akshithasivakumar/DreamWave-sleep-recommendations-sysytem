import pandas as pd
import numpy as np
import random

# Helper function to randomly select recommendations
def generate_recommendations(category):
    sleep_recommendations = [
        "Establish a regular sleep routine", "Avoid screens 30 minutes before bed", "Try a sleep aid like melatonin",
        "Create a relaxing bedtime ritual", "Limit naps to 20 minutes", "Try meditation or deep breathing before sleep"
    ]
    
    diet_recommendations = [
        "Eat more magnesium-rich foods", "Avoid heavy meals before bedtime", "Limit caffeine intake",
        "Drink a glass of water before bed", "Avoid alcohol in the evening", "Eat a balanced dinner"
    ]
    
    exercise_recommendations = [
        "Try a morning jog or brisk walk", "Engage in yoga or stretching exercises", "Focus on strength training",
        "Get 20-30 minutes of exercise daily", "Avoid intense workouts close to bedtime", "Try relaxation exercises before bed"
    ]
    
    stress_management_recommendations = [
        "Practice mindfulness meditation", "Take a warm bath before bed", "Use deep breathing exercises",
        "Journal your thoughts to reduce anxiety", "Consider cognitive behavioral therapy for stress", "Practice gratitude"
    ]
    
    if category == "sleep":
        return random.choice(sleep_recommendations)
    elif category == "diet":
        return random.choice(diet_recommendations)
    elif category == "exercise":
        return random.choice(exercise_recommendations)
    elif category == "stress":
        return random.choice(stress_management_recommendations)

# Generate synthetic data for 100 users
num_users = 100
data = []

for _ in range(num_users):
    # Sleep Schedule & Patterns (Sample questions)
    sleep_schedule = random.choice(["Regular", "Irregular"])
    sleep_hours = random.randint(5, 10)
    trouble_sleeping = random.choice([0, 1])  # 0 for no, 1 for yes
    wake_up_rested = random.choice([0, 1])  # 0 for no, 1 for yes
    sleep_disruptions = random.choice([0, 1])  # 0 for no, 1 for yes
    wake_up_tired = random.choice([0, 1])  # 0 for no, 1 for yes

    # Diet & Nutrition (Sample questions)
    caffeine_intake = random.randint(0, 4)  # Number of caffeinated drinks per day
    eat_heavy_meals = random.choice([0, 1])  # 0 for no, 1 for yes
    eat_before_bed = random.choice([0, 1])  # 0 for no, 1 for yes
    alcohol_consumption = random.choice([0, 1])  # 0 for no, 1 for yes
    fluid_intake = random.randint(3, 12)  # Liters of water consumed daily
    high_protein = random.choice([0, 1])  # 0 for no, 1 for yes

    # Exercise & Activity (Sample questions)
    exercise_frequency = random.choice(["Never", "Occasionally", "Regularly"])
    exercise_intensity = random.choice(["Low", "Moderate", "High"])
    exercise_sleep_quality = random.choice([0, 1])  # 0 for no, 1 for yes

    # Stress & Mood (Sample questions)
    stress_level = random.randint(1, 10)  # Scale from 1 to 10
    main_stressors = random.choice(["Work", "Family", "Finances", "Health", "Relationships", "Other"])
    stress_management = random.choice([0, 1])  # 0 for no, 1 for yes
    mood_swings = random.choice([0, 1])  # 0 for no, 1 for yes
    stress_sleep_disruption = random.choice([0, 1])  # 0 for no, 1 for yes
    relaxation_before_bed = random.choice([0, 1])  # 0 for no, 1 for yes

    # Adding input data to the list
    data.append([sleep_schedule, sleep_hours, trouble_sleeping, wake_up_rested, sleep_disruptions, wake_up_tired,
                 caffeine_intake, eat_heavy_meals, eat_before_bed, alcohol_consumption, fluid_intake, high_protein,
                 exercise_frequency, exercise_intensity, exercise_sleep_quality,
                 stress_level, main_stressors, stress_management, mood_swings, stress_sleep_disruption, relaxation_before_bed])

# Creating the DataFrame
columns = [
    'Sleep Schedule', 'Sleep Hours', 'Trouble Sleeping', 'Wake Up Rested', 'Sleep Disruptions', 'Wake Up Tired',
    'Caffeine Intake', 'Eat Heavy Meals', 'Eat Before Bed', 'Alcohol Consumption', 'Fluid Intake', 'High Protein',
    'Exercise Frequency', 'Exercise Intensity', 'Exercise Sleep Quality',
    'Stress Level', 'Main Stressors', 'Stress Management', 'Mood Swings', 'Stress Sleep Disruption', 'Relaxation Before Bed'
]

df = pd.DataFrame(data, columns=columns)

# Generating Output Recommendations
df['Sleep Recommendation'] = df['Sleep Schedule'].apply(lambda x: generate_recommendations('sleep'))
df['Diet Recommendation'] = df['Caffeine Intake'].apply(lambda x: generate_recommendations('diet'))
df['Exercise Recommendation'] = df['Exercise Frequency'].apply(lambda x: generate_recommendations('exercise'))
df['Stress Recommendation'] = df['Stress Level'].apply(lambda x: generate_recommendations('stress'))

# Save to CSV in the specified directory
df.to_csv('E:/Dreamwave/data/synthetic_sleep_data.csv', index=False)

# Displaying the synthetic dataset (optional)
print(df.head())
