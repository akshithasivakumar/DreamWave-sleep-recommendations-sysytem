from flask import Flask, render_template, request
import pandas as pd
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import LabelEncoder

app = Flask(__name__)

# Load dataset
df = pd.read_csv("data/synthetic_sleep_data.csv")

# Encode any non-numeric columns
for col in df.columns:
    if df[col].dtype == "object":
        encoder = LabelEncoder()
        df[col] = encoder.fit_transform(df[col])

# Split features and labels
features = df.drop(columns=[
    "Main Stressors",
    "Sleep Recommendation",
    "Diet Recommendation",
    "Exercise Recommendation",
    "Stress Recommendation"
])
print("Feature columns:", features.columns.tolist())

labels_sleep = df["Sleep Recommendation"]
labels_diet = df["Diet Recommendation"]
labels_exercise = df["Exercise Recommendation"]
labels_stress = df["Stress Recommendation"]

# Train KNN models
knn_sleep = KNeighborsClassifier(n_neighbors=5)
knn_sleep.fit(features, labels_sleep)

knn_diet = KNeighborsClassifier(n_neighbors=5)
knn_diet.fit(features, labels_diet)

knn_exercise = KNeighborsClassifier(n_neighbors=5)
knn_exercise.fit(features, labels_exercise)

knn_stress = KNeighborsClassifier(n_neighbors=5)
knn_stress.fit(features, labels_stress)

# Mapping for human-understandable recommendations
sleep_suggestions = {
    0: "Your sleep schedule is inconsistent. Try going to bed and waking up at the same time every day to regulate your internal clock. Consistency is key for quality sleep.",
    1: "You may benefit from reducing screen time at least an hour before bed. The blue light from phones, tablets, and computers can interfere with your natural sleep cycle.",
    2: "You should consider practicing relaxation techniques before bed, such as deep breathing or meditation, to help calm your mind and prepare for sleep.",
    3: "If you’re waking up feeling tired despite getting enough hours of sleep, evaluate your sleep environment. Keep your room cool, dark, and quiet to create a more restful atmosphere.",
    4: "Consider journaling or making a to-do list before bed to clear your mind of any thoughts that might keep you awake. A calm mind leads to better sleep.",
    5: "It may help to reduce your caffeine and sugar intake after 2 PM. Both can stimulate your body and interfere with your ability to fall asleep easily.",
    6: "If you find yourself waking up frequently during the night, try implementing a bedtime routine to signal to your body that it’s time to wind down, such as reading a book or taking a warm bath."
}

diet_suggestions = {
    0: "Reduce your caffeine intake quantity, especially in the late afternoon and evening. Try switching to herbal tea or water to avoid interfering with your sleep.",
    1: "You should consider incorporating more high-protein foods like eggs, beans, or lean meats into your meals, as they can help with energy levels and improve sleep quality.",
    2: "Try to avoid eating large, heavy meals or spicy foods too close to bedtime. These can cause indigestion or discomfort, making it harder to fall asleep.",
    3: "Eat a balanced diet rich in vegetables, whole grains, and lean proteins. A healthy gut can positively influence your sleep quality.",
    4: "Cutting down on processed foods and sugar, especially in the evening, can help prevent blood sugar spikes and crashes that could interfere with a restful night’s sleep.",
    5: "Increase your intake of foods rich in magnesium and calcium, such as leafy greens and dairy products, as they help with muscle relaxation and can improve sleep quality.",
    6: "Make sure you're eating dinner at least 2-3 hours before bed to allow for proper digestion before sleep."
}

exercise_suggestions = {
    0: "Consider adding some form of physical activity to your routine, such as walking or stretching. Even a small amount of movement during the day can improve your sleep quality.",
    1: "If you're exercising regularly, try increasing the intensity of your workouts to promote better sleep. Vigorous exercise can help you fall asleep faster and improve sleep quality.",
    2: "Ensure that you’re exercising earlier in the day rather than right before bed, as intense physical activity too close to bedtime can make it harder to fall asleep.",
    3: "Make sure to balance cardio and strength exercises. Both are crucial for maintaining overall health and enhancing sleep quality.",
    4: "Take rest days to avoid overexertion, which can increase stress levels and disrupt sleep."
}

stress_suggestions = {
    0: "Consider incorporating mindfulness practices such as meditation, yoga, or deep breathing exercises into your daily routine to reduce stress and improve sleep.",
    1: "You may benefit from seeking support through counseling or talking to someone you trust to manage high stress levels.",
    2: "Take regular breaks during work or stressful activities to clear your mind and reduce anxiety.",
    3: "Make sure you’re getting enough sleep, as chronic stress can lead to sleep deprivation, which in turn worsens stress. A healthy sleep cycle is crucial.",
    4: "Practice relaxation techniques before bed, like listening to calming music or doing progressive muscle relaxation to reduce nighttime stress."
}

# Home route (Landing page)
@app.route("/")
def home():
    return render_template("index.html")

# Form route
@app.route("/form", methods=["GET", "POST"])
def form():
    if request.method == "POST":
        try:
            user_data = [
                int(request.form["sleep_schedule"]),
                int(request.form["sleep_hours"]),
                int(request.form["trouble_sleeping"]),
                int(request.form["wake_up_rested"]),
                int(request.form["sleep_disruptions"]),
                int(request.form["wake_up_tired"]),
                int(request.form["caffeine_intake"]),
                int(request.form["eat_heavy_meals"]),
                int(request.form["eat_before_bed"]),
                int(request.form["alcohol_consumption"]),
                float(request.form["fluid_intake"]),
                int(request.form["high_protein"]),
                int(request.form["exercise_frequency"]),
                int(request.form["exercise_intensity"]),
                int(request.form["exercise_sleep_quality"]),
                int(request.form["stress_level"]),
                int(request.form["stress_management"]),
                int(request.form["mood_swings"]),
                int(request.form["stress_sleep_disruption"]),
                int(request.form["relaxation_before_bed"]),
            ]

            print("User Data:", user_data)

            sleep_recommendation = knn_sleep.predict([user_data])[0]
            diet_recommendation = knn_diet.predict([user_data])[0]
            exercise_recommendation = knn_exercise.predict([user_data])[0]
            stress_recommendation = knn_stress.predict([user_data])[0]

            print("Predicted values - sleep:", sleep_recommendation,
                  "diet:", diet_recommendation,
                  "exercise:", exercise_recommendation,
                  "stress:", stress_recommendation)

            sleep_advice = sleep_suggestions.get(sleep_recommendation, "Your sleep schedule is awesome")
            diet_advice = diet_suggestions.get(diet_recommendation, "Your diet is great")
            exercise_advice = exercise_suggestions.get(exercise_recommendation, "Great going with the exercise!")
            stress_advice = stress_suggestions.get(stress_recommendation, "Cool that you have no stress!")

            return render_template("results.html",
                                   sleep_advice=sleep_advice,
                                   diet_advice=diet_advice,
                                   exercise_advice=exercise_advice,
                                   stress_advice=stress_advice)
        except Exception as e:
            print("Error during prediction:", e)
            return f"Something went wrong. Please check your inputs. Error: {e}"

    return render_template("form.html")

if __name__ == "__main__":
    app.run(debug=True)
